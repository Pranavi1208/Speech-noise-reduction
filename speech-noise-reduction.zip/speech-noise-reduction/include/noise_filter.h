#ifndef WAV_READER_H
#define WAV_READER_H
#define SPEECH_THRESHOLD_FACTOR 0.4

#include <stdio.h>

#pragma pack(push, 1)

typedef struct
{
    char riff[4];
    int chunk_size;
    char wave[4];
    char fmt[4];
    int subchunk1_size;
    short audio_format;
    short num_channels;
    int sample_rate;
    int byte_rate;
    short block_align;
    short bits_per_sample;
    char data[4];
    int data_size;
} WAVHeader;

#pragma pack(pop)

// Function declarations

int read_wav(const char *filename, WAVHeader *header);

void moving_average(short *samples, short *filtered_samples, size_t number_of_samples, size_t window_size);

int write_wav(const char *filename, WAVHeader *header, short *samples, size_t number_of_samples);

// double estimate_noise_power(short *samples, size_t number_of_samples, size_t noise_samples);

// improved - 
 double estimate_noise_power( short *samples, size_t number_of_samples, size_t window_size, int *speech_flags);

double estimate_signal_power(short *samples, size_t number_of_samples, size_t index, size_t window_size);

double calculate_gain(double signal_power, double noise_power);

void wiener_filter(short *samples, short *filtered_samples, size_t number_of_samples, size_t signal_window_size, size_t speech_window_size, int *speech_flags);

void estimate_noise_spectrum(short *samples, double *noise_spectrum, size_t number_of_samples, size_t frame_size, int *speech_flags);

double avg_amplitude( short *window, size_t window_size);

void detect_speech(short *samples, size_t number_of_samples, size_t window_size, int *speech_flags);

void spectral_subtraction(short *samples, short *filtered_samples, size_t number_of_samples, size_t frame_size, double *noise_spectrum, int *speech_flags);



#endif

